package com.isea533.mybatis.mapper;

import com.isea533.mybatis.model.TbItem;
import tk.mybatis.mapper.common.Mapper;

public interface TbItemMapper extends Mapper<TbItem> {
}